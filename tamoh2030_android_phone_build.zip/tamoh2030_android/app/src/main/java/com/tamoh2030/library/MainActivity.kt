package com.tamoh2030.library

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF0B4F82)
private val Blue = Color(0xFF149BD7)
private val Teal = Color(0xFF19A98A)
private val Gold = Color(0xFFD99A1A)
private val Background = Color(0xFFF7FAFC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TamohApp() }
    }
}

data class AppConfig(
    val whatsapp1: String,
    val whatsapp2: String,
    val whatsapp3: String,
    val groupUrl: String,
    val catalogUrl: String
)

data class LibraryFile(val id: String, val title: String, val category: String, val description: String, val url: String = "")

val categories = listOf(
    "الأداء الوظيفي" to Icons.Default.Assignment,
    "البحوث المدرسية" to Icons.Default.Search,
    "التحاضير والدروس" to Icons.Default.MenuBook,
    "أوراق العمل" to Icons.Default.Description,
    "سجلات ونماذج" to Icons.Default.AssignmentTurnedIn,
    "ملفات المعلمين والمعلمات" to Icons.Default.Badge,
    "ملفات الطلاب والطالبات" to Icons.Default.School,
    "الأنشطة المدرسية" to Icons.Default.Groups,
    "نماذج وخطط مدرسية" to Icons.Default.EditNote,
    "عروض تقديمية" to Icons.Default.PresentToAll
)

fun loadConfig(context: Context): AppConfig {
    val p = context.getSharedPreferences("tamoh", Context.MODE_PRIVATE)
    return AppConfig(
        p.getString("w1", "96677576823") ?: "",
        p.getString("w2", "966571544400") ?: "",
        p.getString("w3", "") ?: "",
        p.getString("group", "https://chat.whatsapp.com/CHb0JfnQQnt2YMamToOfZT?s=sw&p=a&mlu=4") ?: "",
        p.getString("catalog", "") ?: ""
    )
}

fun saveConfig(context: Context, c: AppConfig) {
    context.getSharedPreferences("tamoh", Context.MODE_PRIVATE).edit()
        .putString("w1", c.whatsapp1).putString("w2", c.whatsapp2).putString("w3", c.whatsapp3)
        .putString("group", c.groupUrl).putString("catalog", c.catalogUrl).apply()
}

@Composable
fun TamohApp() {
    val context = LocalContext.current
    var config by remember { mutableStateOf(loadConfig(context)) }
    var tab by remember { mutableIntStateOf(0) }
    var selectedFile by remember { mutableStateOf<LibraryFile?>(null) }
    var selectedCategory by remember { mutableStateOf<String?>(null) }
    MaterialTheme(colorScheme = lightColorScheme(primary = Navy, secondary = Blue, tertiary = Gold)) {
        Scaffold(bottomBar = { BottomNav(tab) { tab = it } }) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                if (selectedFile != null) {
                    FileDetails(selectedFile!!) { selectedFile = null }
                } else when (tab) {
                    0 -> Home(config) { tab = 1 }
                    1 -> LibraryScreen(selectedCategory) { selectedCategory = it }
                    2 -> DownloadsScreen()
                    3 -> Announcements(config)
                    else -> SettingsScreen(config) { c -> saveConfig(context, c); config = c }
                }
            }
        }
    }
}

@Composable fun Header() {
    Column(Modifier.fillMaxWidth().background(Color.White)) {
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Image(bitmap = androidx.compose.ui.res.ImageBitmap.imageResource(R.drawable.logo_tamoh), contentDescription = "شعار مكتبة طموح 2030", modifier = Modifier.size(76.dp))
            Column(horizontalAlignment = Alignment.End) {
                Text("مكتبة طموح 2030", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Navy)
                Text("رؤية تحقق.. وإنجاز يوثق", color = Blue, fontSize = 13.sp)
            }
            Icon(Icons.Default.Menu, contentDescription = "القائمة", tint = Navy, modifier = Modifier.size(30.dp))
        }
    }
}

@Composable fun Home(config: AppConfig, onLibrary: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).background(Background)) {
        Header()
        OutlinedTextField(value = "", onValueChange = {}, placeholder = { Text("ابحث عن ملف تعليمي...") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(12.dp), shape = RoundedCornerShape(30.dp))
        Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp), colors = CardDefaults.cardColors(containerColor = Navy), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(20.dp)) {
                Text("كل ما تحتاجه من ملفات وأعمال مدرسية", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("في مكان واحد", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
                Text("محتوى تعليمي سعودي منظم وسهل الوصول", color = Color.White.copy(.9f), modifier = Modifier.padding(top = 6.dp))
            }
        }
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Quick("المكتبة التعليمية", Icons.Default.Folder, Blue, onLibrary)
            Quick("البحث السريع", Icons.Default.Search, Color(0xFF7655D9), onLibrary)
            Quick("أحدث الملفات", Icons.Default.Schedule, Teal, onLibrary)
            Quick("المميزة", Icons.Default.Star, Gold, onLibrary)
        }
        Text("أقسام الملفات", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Navy, modifier = Modifier.padding(16.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(2), modifier = Modifier.height(620.dp).padding(horizontal = 10.dp), userScrollEnabled = false, verticalArrangement = Arrangement.spacedBy(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(categories) { (name, icon) -> Category(name, icon, onLibrary) }
        }
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (config.whatsapp1.isNotBlank()) ContactButton("واتساب 1", config.whatsapp1, Teal)
            if (config.whatsapp2.isNotBlank()) ContactButton("واتساب 2", config.whatsapp2, Blue)
        }
        if (config.whatsapp3.isNotBlank()) ContactButtonSingle("واتساب 3", config.whatsapp3, Navy)
        Button(onClick = { openUrl(LocalContext.current, config.groupUrl) }, modifier = Modifier.fillMaxWidth().padding(12.dp), shape = RoundedCornerShape(14.dp)) {
            Icon(Icons.Default.Groups, null); Spacer(Modifier.width(8.dp)); Text("انضم إلى مجموعة واتساب للإعلانات")
        }
        Spacer(Modifier.height(20.dp))
    }
}

@Composable fun Quick(t: String, icon: androidx.compose.ui.graphics.vector.ImageVector, c: Color, click: () -> Unit) = Card(Modifier.weight(1f).height(96.dp).clickable { click() }, colors = CardDefaults.cardColors(containerColor = c), shape = RoundedCornerShape(14.dp)) { Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(29.dp)); Text(t, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(4.dp)) } }

@Composable fun Category(t: String, icon: androidx.compose.ui.graphics.vector.ImageVector, click: () -> Unit) = Card(Modifier.fillMaxWidth().height(112.dp).clickable { click() }, shape = RoundedCornerShape(16.dp)) { Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) { Icon(icon, null, tint = Blue, modifier = Modifier.size(34.dp)); Text(t, color = Navy, fontWeight = FontWeight.Bold, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(6.dp)) } }

@Composable fun ContactButton(label: String, number: String, c: Color) { val ctx = LocalContext.current; Button(onClick = { openUrl(ctx, "https://wa.me/${number.filter { it.isDigit() }}") }, colors = ButtonDefaults.buttonColors(containerColor = c), modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) { Icon(Icons.Default.Chat, null); Spacer(Modifier.width(5.dp)); Text(label) } }
@Composable fun ContactButtonSingle(label: String, number: String, c: Color) { val ctx = LocalContext.current; Button(onClick = { openUrl(ctx, "https://wa.me/${number.filter { it.isDigit() }}") }, colors = ButtonDefaults.buttonColors(containerColor = c), modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp), shape = RoundedCornerShape(14.dp)) { Icon(Icons.Default.Chat, null); Spacer(Modifier.width(6.dp)); Text(label) } }

@Composable fun LibraryScreen(selectedCategory: String?, onCategory: (String) -> Unit) {
    var query by remember { mutableStateOf("") }
    val sample = remember { categories.mapIndexed { i, p -> LibraryFile("sample$i", "ملفات ${p.first}", p.first, "قسم جاهز لاستقبال الملفات التعليمية من لوحة إدارة المكتبة.") } }
    val shown = sample.filter { (selectedCategory == null || it.category == selectedCategory) && it.title.contains(query, true) }
    Column(Modifier.fillMaxSize().background(Background).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { if (!selectedCategory.isNullOrBlank()) IconButton(onClick = { onCategory("") }) { Icon(Icons.Default.ArrowBack, "رجوع") }; Text(if (selectedCategory.isNullOrBlank()) "المكتبة التعليمية" else selectedCategory, fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Navy) }
        OutlinedTextField(value = query, onValueChange = { query = it }, placeholder = { Text("ابحث داخل المكتبة") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp), shape = RoundedCornerShape(25.dp))
        if (selectedCategory.isNullOrBlank()) {
            Text("التصنيفات", fontWeight = FontWeight.Bold, color = Navy, fontSize = 18.sp)
            LazyColumn { items(categories) { (name, _) -> Card(Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable { onCategory(name) }, shape = RoundedCornerShape(14.dp)) { Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Folder, null, tint = Blue); Spacer(Modifier.width(12.dp)); Text(name, fontWeight = FontWeight.Bold, color = Navy) } } } }
        } else {
            Text("الملفات المتاحة", fontWeight = FontWeight.Bold, color = Navy, fontSize = 18.sp)
            LazyColumn { items(shown) { f -> FileCard(f) } }
        }
    }
}

@Composable fun FileCard(file: LibraryFile) {
    Card(Modifier.fillMaxWidth().padding(vertical = 5.dp), shape = RoundedCornerShape(15.dp)) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Description, null, tint = Blue, modifier = Modifier.size(36.dp)); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(file.title, fontWeight = FontWeight.Bold, color = Navy); Text(file.description, color = Color.Gray, fontSize = 12.sp) }; Icon(Icons.Default.ChevronLeft, null, tint = Navy) } }
}

@Composable fun FileDetails(file: LibraryFile, back: () -> Unit) { val ctx = LocalContext.current; Column(Modifier.fillMaxSize().background(Background).padding(18.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = back) { Icon(Icons.Default.ArrowBack, "رجوع") }; Text("تفاصيل الملف", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Navy) }; Spacer(Modifier.height(24.dp)); Icon(Icons.Default.Description, null, tint = Blue, modifier = Modifier.size(70.dp).align(Alignment.CenterHorizontally)); Text(file.title, fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Navy, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 16.dp)); Text(file.category, color = Blue, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(8.dp)); Text(file.description, color = Color.DarkGray, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(16.dp)); if (file.url.isNotBlank()) Button(onClick = { downloadFile(ctx, file.url, file.title) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Download, null); Spacer(Modifier.width(8.dp)); Text("تحميل الملف") } else Text("سيظهر زر التحميل عند نشر رابط الملف من لوحة الإدارة.", color = Color.Gray, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(20.dp)) } }

@Composable fun DownloadsScreen() = Empty("تحميلاتي", "ستظهر الملفات التي تقوم بتحميلها هنا", Icons.Default.Download)
@Composable fun Announcements(config: AppConfig) { val ctx = LocalContext.current; Column(Modifier.fillMaxSize().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text("الإعلانات", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Navy); Spacer(Modifier.height(20.dp)); Text("تابع أحدث الملفات والإعلانات عبر واتساب", textAlign = TextAlign.Center, color = Color.Gray); Button(onClick = { openUrl(ctx, config.groupUrl) }, modifier = Modifier.fillMaxWidth().padding(top = 20.dp)) { Icon(Icons.Default.Groups, null); Spacer(Modifier.width(8.dp)); Text("فتح مجموعة واتساب") } } }
@Composable fun Empty(title: String, sub: String, icon: androidx.compose.ui.graphics.vector.ImageVector) = Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) { Icon(icon, null, tint = Blue, modifier = Modifier.size(70.dp)); Text(title, fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Navy); Text(sub, color = Color.Gray, modifier = Modifier.padding(12.dp)) }

@Composable fun SettingsScreen(config: AppConfig, onSave: (AppConfig) -> Unit) {
    var w1 by remember { mutableStateOf(config.whatsapp1) }; var w2 by remember { mutableStateOf(config.whatsapp2) }; var w3 by remember { mutableStateOf(config.whatsapp3) }; var group by remember { mutableStateOf(config.groupUrl) }; var catalog by remember { mutableStateOf(config.catalogUrl) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
        Text("إعدادات المكتبة", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Navy)
        Text("تعديل بيانات التواصل من داخل التطبيق", color = Color.Gray, modifier = Modifier.padding(bottom = 12.dp))
        listOf("واتساب 1" to w1, "واتساب 2" to w2, "واتساب 3" to w3).forEachIndexed { i, pair -> OutlinedTextField(value = pair.second, onValueChange = { v -> when (i) { 0 -> w1 = v; 1 -> w2 = v; else -> w3 = v } }, label = { Text(pair.first) }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)) }
        OutlinedTextField(value = group, onValueChange = { group = it }, label = { Text("رابط مجموعة واتساب") }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp))
        OutlinedTextField(value = catalog, onValueChange = { catalog = it }, label = { Text("رابط كتالوج المكتبة السحابي - اختياري") }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp))
        Button(onClick = { onSave(AppConfig(w1, w2, w3, group, catalog)) }, modifier = Modifier.fillMaxWidth().padding(top = 12.dp)) { Icon(Icons.Default.Save, null); Spacer(Modifier.width(8.dp)); Text("حفظ الإعدادات") }
        Card(Modifier.fillMaxWidth().padding(top = 18.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFF0F6FA))) { Text("ملاحظة: هذه النسخة تحفظ إعدادات التواصل على الجهاز. الإدارة المشتركة للملفات بين جميع المستخدمين تحتاج ربط قاعدة بيانات وتخزين سحابي خاص بالمكتبة.", color = Navy, fontSize = 13.sp, modifier = Modifier.padding(14.dp)) }
    }
}

@Composable fun BottomNav(tab: Int, onTab: (Int) -> Unit) { NavigationBar { listOf("الرئيسية" to Icons.Default.Home, "المكتبة" to Icons.Default.Folder, "تحميلاتي" to Icons.Default.Download, "الإعلانات" to Icons.Default.Notifications, "المزيد" to Icons.Default.Settings).forEachIndexed { i, p -> NavigationBarItem(selected = tab == i, onClick = { onTab(i) }, icon = { Icon(p.second, null) }, label = { Text(p.first) }) } } }

fun openUrl(context: Context, url: String) { if (url.isBlank()) return; try { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) {} }
fun downloadFile(context: Context, url: String, title: String) { val request = DownloadManager.Request(Uri.parse(url)).setTitle(title).setDescription("مكتبة طموح 2030").setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED).setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, title.replace("/", "_") + ".pdf"); (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request) }
